package fileServidor;

public class FileServidorImpl extends java.rmi.server.UnicastRemoteObject implements FileServidor {
    public FileServidorImpl() throws java.rmi.RemoteException {
        super();
    }
    public void abreLee(String nombreArchivo, fileServidorCliente.FileReceptor receptor)
		    throws java.rmi.RemoteException , java.io.IOException, java.io.FileNotFoundException {
        java.io.BufferedReader br;
	br=new java.io.BufferedReader(new java.io.FileReader(nombreArchivo));
	String linea=br.readLine();
	while(linea!=null){
	receptor.recibeLinea(linea);
	linea=br.readLine();
	}
        //algo
    }
}
